
//#ifndef CLK_TCK
//#define CLK_TCK 1000
//#endif //CLK_TK
#   define CLK_TCK    CLOCKS_PER_SEC

